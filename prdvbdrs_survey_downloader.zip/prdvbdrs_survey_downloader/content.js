(function createDropdownButtonProgress() {
  let gpPasswords = {};

  fetch("https://raw.githubusercontent.com/aslamkd/appdata/refs/heads/main/prdDownloadPass.json")
    .then(res => res.json())
    .then(data => { gpPasswords = data; });

  const container = document.createElement("div");
  container.style.position = "fixed";
  container.style.bottom = "20px";
  container.style.right = "20px";
  container.style.background = "#fff";
  container.style.padding = "10px";
  container.style.border = "1px solid #ccc";
  container.style.zIndex = 9999;
  container.style.fontFamily = "Arial, sans-serif";
  container.style.boxShadow = "0 0 8px rgba(0,0,0,0.2)";

  container.innerHTML = `
    <select id="gppicker_ext" style="margin-bottom:5px;width:200px;">
      <option value="0" data-boundary-id="">Select GP</option>
      <option value="6" data-boundary-id="839">KARIMPUR-I</option>
      <option value="6" data-boundary-id="840">KARIMPUR-II</option>
      <option value="6" data-boundary-id="841">JAMSHERPUR</option>
      <option value="6" data-boundary-id="842">MAGHUGARI</option>
      <option value="6" data-boundary-id="843">HOGALBARIA</option>
      <option value="6" data-boundary-id="844">PIPULBERIA</option>
      <option value="6" data-boundary-id="845">HAREKRISHNAPUR</option>
      <option value="6" data-boundary-id="846">SHIKARPUR</option>
    </select><br>
    <button id="downloadSurveyCsv" style="width:200px;">⬇ Download Survey CSV</button>
    <button id="downloadKml" style="width:200px;margin-top:5px;">⬇ Download KML</button>
    <div id="progressBar" style="width:100%;background:#eee;display:none;margin-top:5px;height:20px;position:relative;">
      <div id="progressFill" style="height:100%;width:0%;background:#28a745;"></div>
      <div id="progressCount" style="position:absolute;left:5px;font-size:12px;"></div>
      <div id="progressTotal" style="position:absolute;right:5px;font-size:12px;"></div>
    </div>
  `;
  document.body.appendChild(container);

  document.getElementById("downloadSurveyCsv").addEventListener("click", function () {

    const gpSelect = document.getElementById("gppicker");
    const selectedOption = gpSelect.options[gpSelect.selectedIndex];
    const boundaryID = selectedOption.getAttribute("data-boundary-id");
    const boundaryLevelID = selectedOption.value;

    if (!boundaryID || boundaryID === "0") {
      alert("GP নির্বাচন করুন");
      return;
    }

    const correctPassword = gpPasswords[boundaryID];
    if (correctPassword) {
      if (prompt("🔒 পাসওয়ার্ড দিন:") !== correctPassword) {
        alert("ভুল পাসওয়ার্ড");
        return;
      }
    }

    const progressBar = document.getElementById("progressBar");
    const progressFill = document.getElementById("progressFill");
    progressBar.style.display = "block";

    fetch(`https://prdvbdrs.in/getGeoJsonDetails?BoundaryID=${boundaryID}&BoundaryLevelID=${boundaryLevelID}`, {
      headers: { "x-requested-with": "XMLHttpRequest" }
    })
    .then(res => res.json())
    .then(async data => {

      const features = JSON.parse(data.geoJson).features;
      window.allFeaturesForKML = features;

      const csrfHeader = document.querySelector("meta[name='_csrf_header']")?.content;
      const csrfToken = document.querySelector("meta[name='_csrf']")?.content;
      const contextPath = document.getElementById("contextPath")?.value || "";

      const headers = [
        "survey_id","survey_type_id","district_name","block_name","gram_panchayet_name",
        "gram_sansad_name","para_name","survey_date","family_head_name",
        "family_head_guardian_name","hh_contact_no","total_family_member",
        "is_mosquito_larvae_found","latitude","longitude","surveyor_name",
        "surveyor_contact_no","Map"
      ];

      const CHUNK_SIZE = 1200;
      let csvRows = [headers.join(",")];
      let fileIndex = 1;
      let completed = 0;

      function downloadChunk() {
        const blob = new Blob([csvRows.join("\n")], { type: "text/csv;charset=utf-8;" });
        const a = document.createElement("a");
        const gpName = selectedOption.textContent.trim().replace(/\s+/g, "_");
        a.href = URL.createObjectURL(blob);
        a.download = `survey_details_gp_${gpName}_${boundaryID}_part${fileIndex}.csv`;
        a.click();
        fileIndex++;
        csvRows = [headers.join(",")];
      }

      for (const f of features) {
        const res = await fetch(contextPath + "/getSurveytypeInfo", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            ...(csrfHeader && csrfToken ? { [csrfHeader]: csrfToken } : {})
          },
          body: new URLSearchParams({
            survey_id: f.properties.survey_id,
            survey_type_id: f.properties.survey_type_id
          })
        });

        const detail = await res.json();
        f.detail = detail;

        const lat = detail.house?.latitude || "";
        const lng = detail.house?.longitude || "";
        const mapLink = lat && lng
          ? `"=HYPERLINK(""https://www.google.com/maps?q=${lat},${lng}"",""View Map"")"`
          : "";

        csvRows.push([
          f.properties.survey_id,
          f.properties.survey_type_id,
          detail.house?.district_name || "",
          detail.house?.block_name || "",
          detail.house?.gram_panchayet_name || "",
          detail.house?.gram_sansad_name || "",
          detail.house?.para_name || "",
          detail.house?.house_survey_date || "",
          detail.house?.family_head_name || "",
          detail.house?.family_head_guardian_name || "",
          detail.house?.hh_contact_no || "",
          detail.house?.total_family_member || "",
          detail.house?.is_mosquito_larvae_found || "",
          lat, lng,
          detail.house?.surveyor_name || "",
          detail.house?.surveyor_contact_no || "",
          mapLink
        ].join(","));

        completed++;
        progressFill.style.width = ((completed / features.length) * 100).toFixed(1) + "%";
        document.getElementById("progressCount").textContent = completed;
        document.getElementById("progressTotal").textContent = features.length;

        if (csvRows.length === CHUNK_SIZE + 1) {
          downloadChunk();
        }

        await new Promise(r => setTimeout(r, 300)); // 🔒 resource safe
      }

      if (csvRows.length > 1) {
        downloadChunk();
      }

      alert("✅ সব CSV ডাউনলোড সম্পন্ন");
      progressBar.style.display = "none";
    });
  });

})();
